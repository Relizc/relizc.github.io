import os
import sqlite3
import hmac
import hashlib
import base64
import time
import json
import secrets
import string
import subprocess
from pathlib import Path
from flask import (
    Flask, request, render_template, jsonify, abort, send_from_directory,
    redirect, url_for
)
from werkzeug.utils import secure_filename
from urllib.parse import quote_plus

# ---------- Configuration ----------
BASE_DIR = Path(__file__).parent
UPLOAD_DIR = BASE_DIR / "uploads"
DB_PATH = BASE_DIR / "metadata.db"
ALLOWED_EXTENSIONS = None  # we accept many audio types, will check with ffprobe
MAX_UPLOAD_SIZE = 50 * 1024 * 1024  # 50 MB

# token secret (in production keep this in env var)
TOKEN_SECRET = os.environ.get("UPLOAD_TOKEN_SECRET", "replace-me-with-secure-random")
TOKEN_EXPIRY_SECONDS = 5 * 60  # upload token valid for 5 minutes

# URL base for generated permalinks, adjust if different host/port:
PERMALINK_PREFIX = "/m/"

# list of codecs considered lossless (ffprobe codec_name values)
LOSSLESS_CODECS = {
    "flac", "alac", "pcm_s16le", "pcm_s24le", "pcm_s32le", "pcm_u8", "wav",
    "pcm_s16be", "pcm_s24be", "pcm_f32le"
}

# create upload directory
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# Flask app
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = MAX_UPLOAD_SIZE + 1024  # a little buffer

# ---------- Database helpers ----------
def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
    CREATE TABLE IF NOT EXISTS files (
        id TEXT PRIMARY KEY,
        hash TEXT UNIQUE,
        stored_filename TEXT,
        original_filename TEXT,
        content_type TEXT,
        size INTEGER,
        created_at INTEGER,
        title TEXT,
        artist TEXT,
        album TEXT
    )
    ''')
    conn.commit()
    conn.close()

def db_get_by_hash(h):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT id, stored_filename FROM files WHERE hash = ?', (h,))
    row = c.fetchone()
    conn.close()
    return row

def db_insert_file(pid, hashval, stored_filename, orig_name, content_type, size,
                   title="Unknown", artist="Unknown", album="Unknown"):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute(
        """INSERT INTO files
           (id, hash, stored_filename, original_filename, content_type, size, created_at, title, artist, album)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (pid, hashval, stored_filename, orig_name, content_type, size, int(time.time()), title, artist, album)
    )
    conn.commit()
    conn.close()


# ---------- Utility functions ----------
def hmac_sign(payload: bytes) -> str:
    sig = hmac.new(TOKEN_SECRET.encode(), payload, hashlib.sha256).digest()
    return base64.urlsafe_b64encode(sig).rstrip(b"=").decode()

def make_token(data: dict) -> str:
    """
    Token = base64url(payload_json) + "." + signature
    """
    payload = json.dumps(data, separators=(",", ":"), sort_keys=True).encode()
    b64 = base64.urlsafe_b64encode(payload).rstrip(b"=").decode()
    sig = hmac_sign(payload)
    return f"{b64}.{sig}"

def verify_token(token: str) -> dict:
    try:
        b64, sig = token.rsplit(".", 1)
        padding = '=' * (-len(b64) % 4)
        payload = base64.urlsafe_b64decode(b64 + padding)
        expected = hmac_sign(payload)
        # Constant time compare
        if not hmac.compare_digest(expected, sig):
            raise ValueError("invalid signature")
        data = json.loads(payload)
        if data.get("exp", 0) < time.time():
            raise ValueError("expired")
        return data
    except Exception as e:
        raise ValueError("invalid token") from e

def rand_id(n=8):
    # base62-like id
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(n))

def run_ffprobe(file_path):
    """Return parsed ffprobe json output for streams"""
    cmd = [
        "ffprobe", "-v", "error", "-show_entries", "format:stream", 
        "-of", "json", str(file_path)
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError(f"ffprobe error: {proc.stderr}")
    return json.loads(proc.stdout)

def detect_lossless(file_path) -> bool:
    info = run_ffprobe(file_path)
    # inspect first audio stream codec_name
    streams = info.get("streams", [])
    for s in streams:
        if s.get("codec_type") == "audio":
            codec = s.get("codec_name","").lower()
            if codec in LOSSLESS_CODECS:
                return True
            # flac can sometimes appear as flac; wav may be pcm*
            # else assume lossy
            return False
    return False

def hash_audio_via_ffmpeg(file_path) -> str:
    """
    Use ffmpeg to decode to raw PCM and compute SHA-256 over raw PCM bytes.
    This will ignore container metadata and only reflect decoded audio samples.
    """
    # ffmpeg -i input -f s16le -acodec pcm_s16le -ac 2 -ar 44100 -
    # but better: preserve channel count and sample rate by not forcing them
    # Use ffmpeg to output s16le raw audio
    cmd = [
        "ffmpeg", "-v", "error", "-i", str(file_path),
        "-f", "s16le", "-acodec", "pcm_s16le", "-ac", "2", "-ar", "44100", "-"
    ]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    sha = hashlib.sha256()
    try:
        while True:
            chunk = proc.stdout.read(64 * 1024)
            if not chunk:
                break
            sha.update(chunk)
        proc.wait(timeout=30)
    except Exception:
        proc.kill()
        raise
    if proc.returncode != 0:
        stderr = proc.stderr.read().decode(errors="ignore")
        raise RuntimeError(f"ffmpeg failed while hashing: {stderr}")
    return sha.hexdigest()

def convert_to_mp3(input_path: Path, output_path: Path, bitrate="192k"):
    cmd = [
        "ffmpeg", "-y", "-v", "error", "-i", str(input_path),
        "-vn", "-ar", "44100", "-ac", "2", "-b:a", bitrate, str(output_path)
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError(f"ffmpeg convert error: {proc.stderr}")

# ---------- Routes ----------
@app.route("/music")
def index():
    return render_template("index.html")

@app.route("/")
def index2():
    return render_template_string("这里空空如也")

@app.route("/get_upload_token", methods=["POST"])
def get_upload_token():
    """
    Client sends JSON:
    {
      "hash": "<hex sha256 of audio content computed by client>",
      "size": <file_size_bytes>,
      "filename": "<original filename>"
    }
    Server checks size <= MAX_UPLOAD_SIZE and whether hash exists already.
    If OK, returns a signed token the client will present with the upload.
    """
    data = request.get_json(force=True)
    if not data:
        return jsonify({"error": "missing json"}), 400
    file_hash = data.get("hash")
    size = int(data.get("size", 0))
    filename = data.get("filename", "")
    # basic validations
    if not file_hash or len(file_hash) < 10:
        return jsonify({"error": "invalid hash"}), 400
    if size > MAX_UPLOAD_SIZE:
        return jsonify({"error": "file too large"}), 400

    # check duplicate
    existing = db_get_by_hash(file_hash)
    if existing:
        # return the permalink directly so client can skip uploading
        return jsonify({"already_exists": True, "permalink": url_for("serve_by_id", pid=existing[0], _external=True)})

    # create token payload
    payload = {
        "hash": file_hash,
        "size": size,
        "filename": filename,
        "exp": int(time.time() + TOKEN_EXPIRY_SECONDS),
        "nonce": secrets.token_urlsafe(8)
    }
    token = make_token(payload)
    return jsonify({"token": token, "max_size": MAX_UPLOAD_SIZE})


from mutagen import File as MutagenFile

def extract_audio_metadata(filepath: Path) -> dict:
    """Extracts metadata (title, artist, album) from a given audio file.
       Returns defaults if missing."""
    metadata = {"title": "Unknown", "artist": "Unknown", "album": "Unknown"}
    try:
        audio = MutagenFile(filepath)
        if not audio or not hasattr(audio, "tags") or audio.tags is None:
            return metadata

        tags = audio.tags

        # Mutagen tag names differ by format, handle common ones
        title = None
        artist = None
        album = None

        if "TIT2" in tags:  # ID3 title
            title = str(tags["TIT2"])
        elif "title" in tags:
            title = tags["title"][0] if isinstance(tags["title"], list) else str(tags["title"])

        if "TPE1" in tags:  # ID3 artist
            artist = str(tags["TPE1"])
        elif "artist" in tags:
            artist = tags["artist"][0] if isinstance(tags["artist"], list) else str(tags["artist"])

        if "TALB" in tags:  # ID3 album
            album = str(tags["TALB"])
        elif "album" in tags:
            album = tags["album"][0] if isinstance(tags["album"], list) else str(tags["album"])

        if title: metadata["title"] = title.strip()
        if artist: metadata["artist"] = artist.strip()
        if album: metadata["album"] = album.strip()
    except Exception:
        pass  # Ignore parse errors, fallback to Unknown
    return metadata


@app.route("/upload", methods=["POST"])
def upload():
    token = request.form.get("token", "")
    compress_flag = request.form.get("compress", "on")
    compress_flag = True if compress_flag.lower() in ("1", "true", "on", "yes") else False

    if not token:
        return jsonify({"error": "missing token"}), 400
    try:
        data = verify_token(token)
    except Exception:
        return jsonify({"error": "invalid token"}), 400

    if 'file' not in request.files:
        return jsonify({"error": "missing file"}), 400

    f = request.files['file']
    orig_name = secure_filename(f.filename or "upload")

    # Check size again on server side
    f.seek(0, os.SEEK_END)
    filesize = f.tell()
    f.seek(0)
    if filesize > MAX_UPLOAD_SIZE:
        return jsonify({"error": "file too large"}), 400

    temp_name = UPLOAD_DIR / f"tmp_{secrets.token_hex(8)}_{orig_name}"
    f.save(temp_name)

    try:
        # Compute authoritative ffmpeg audio hash (decoded PCM only)
        ffmpeg_hash = hash_audio_via_ffmpeg(temp_name)

        # If same content already exists -> replace file
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT id, stored_filename FROM files WHERE hash = ?", (ffmpeg_hash,))
        row = c.fetchone()
        conn.close()

        # detect lossless
        is_lossless = detect_lossless(temp_name)

        # prepare storage
        if is_lossless and not compress_flag:
            stored_filename = f"{ffmpeg_hash}_{secure_filename(orig_name)}"
            dest = UPLOAD_DIR / stored_filename
            temp_name.replace(dest)
            final_content_type = "audio/" + (Path(orig_name).suffix.lstrip(".") or "octet-stream")
            final_size = dest.stat().st_size
        else:
            out_name = f"{ffmpeg_hash}.mp3"
            out_path = UPLOAD_DIR / out_name
            try:
                convert_to_mp3(temp_name, out_path)
            finally:
                temp_name.unlink(missing_ok=True)
            stored_filename = out_name
            final_content_type = "audio/mpeg"
            final_size = out_path.stat().st_size

                # Extract metadata from the final stored file
        metadata = extract_audio_metadata(UPLOAD_DIR / stored_filename)
        title = metadata["title"]
        artist = metadata["artist"]
        album = metadata["album"]

        # If a file with this hash already exists, replace its file & update metadata
        if row:
            old_id, old_filename = row
            old_path = UPLOAD_DIR / old_filename
            old_path.unlink(missing_ok=True)
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute(
                """UPDATE files
                   SET stored_filename=?, original_filename=?, content_type=?, size=?, created_at=?,
                       title=?, artist=?, album=?
                   WHERE id=?""",
                (stored_filename, orig_name, final_content_type, final_size, int(time.time()),
                 title, artist, album, old_id)
            )
            conn.commit()
            conn.close()
            return jsonify({
                "ok": True,
                "replaced": True,
                "permalink": url_for("serve_by_id", pid=old_id, _external=True)
            })

        # Insert new file with metadata
        new_id = rand_id(10)
        db_insert_file(
            new_id, ffmpeg_hash, stored_filename, orig_name,
            final_content_type, final_size,
            title=title, artist=artist, album=album
        )

        permalink = url_for("serve_by_id", pid=new_id, _external=True)

        return jsonify({"ok": True, "permalink": permalink})

    except Exception as e:
        temp_name.unlink(missing_ok=True)
        return jsonify({"error": str(e)}), 500


@app.route("/m/<pid>")
def serve_by_id(pid):
    # lookup in DB
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT stored_filename FROM files WHERE id = ?', (pid,))
    r = c.fetchone()
    conn.close()
    if not r:
        abort(404)
    stored_filename = r[0]
    # You might want to generate ephemeral signed URLs to files in production
    return send_from_directory(directory=str(UPLOAD_DIR), path=stored_filename, as_attachment=False)


from flask import render_template_string

# ---------- API for fetching songs ----------
@app.route("/api/songs")
def api_songs():
    q = request.args.get("q", "").strip()
    offset = int(request.args.get("offset", 0))
    limit = int(request.args.get("limit", 50))

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    if q:
        like = f"%{q}%"
        c.execute(
            """SELECT id, title, artist, album, original_filename, created_at
               FROM files
               WHERE title LIKE ? OR artist LIKE ? OR album LIKE ? OR original_filename LIKE ?
               ORDER BY created_at DESC
               LIMIT ? OFFSET ?""",
            (like, like, like, like, limit, offset)
        )
    else:
        c.execute(
            """SELECT id, title, artist, album, original_filename, created_at
               FROM files
               ORDER BY created_at DESC
               LIMIT ? OFFSET ?""",
            (limit, offset)
        )
    rows = c.fetchall()
    conn.close()

    result = []
    for row in rows:
        pid, title, artist, album, orig_name, created_at = row
        result.append({
            "id": pid,
            "title": title,
            "artist": artist,
            "album": album,
            "original_filename": orig_name,
            "created_at": created_at,
            "permalink": url_for("serve_by_id", pid=pid, _external=True)
        })
    return jsonify(result)


@app.route("/browse")
def browse_page():
    return render_template("search.html")


# run once at startup
init_db()

if __name__ == "__main__":
    app.run(debug=True, port=5000)



